import { useState } from "react";

/* ─── DATA ─────────────────────────────────────────────── */

const models = [
  {
    id: "S1",
    name: "Solix S1",
    tag: "Equilíbrio Perfeito",
    autonomy: "até 40 km",
    speed: "25 km/h",
    weight: "12 kg",
    charge: "4 – 6 horas",
    motor: "350W",
    battery: "36V – 10Ah (Íon de lítio)",
    tire: '8,5"',
    highlight: "Compacto, prático e sustentável.",
    color: "from-orange-500/20 to-amber-400/5",
    border: "border-orange-500/30",
    image: "/images/solix-s1.jpg",
  },
  {
    id: "S2",
    name: "Solix S2",
    tag: "Mais Potência",
    autonomy: "até 60 km",
    speed: "30 km/h",
    weight: "15 kg",
    charge: "5 – 7 horas",
    motor: "500W",
    battery: "36V – 15Ah (Íon de lítio)",
    tire: '10"',
    highlight: "Perfeito para quem busca mais desempenho e conforto.",
    color: "from-amber-400/20 to-orange-500/5",
    border: "border-amber-400/40",
    image: "/images/solix-s2.jpg",
  },
  {
    id: "S3",
    name: "Solix S3",
    tag: "Liberdade Sem Limites",
    autonomy: "até 80 km",
    speed: "40 km/h",
    weight: "18 kg",
    charge: "6 – 8 horas",
    motor: "750W",
    battery: "48V – 20Ah (Íon de lítio)",
    tire: '10"',
    highlight: "Alta performance para quem quer ir mais longe.",
    color: "from-yellow-400/15 to-orange-600/5",
    border: "border-yellow-400/30",
    image: "/images/solix-s3.jpg",
  },
];

const benefits = [
  {
    icon: "☀️",
    title: "100% Energia Solar",
    desc: "Placas fotovoltaicas integradas ao deck captam a energia do sol e recarregam a bateria sem precisar de tomada.",
  },
  {
    icon: "⚡",
    title: "Zero Emissões",
    desc: "Mobilidade limpa, silenciosa e sustentável para cidades mais inteligentes e um futuro mais verde.",
  },
  {
    icon: "🔧",
    title: "Personalizável",
    desc: "Produtos adaptáveis às necessidades de cada cliente — ideal para prefeituras, frotas e projetos institucionais.",
  },
  {
    icon: "🛡️",
    title: "2 Anos de Garantia",
    desc: "Todos os patinetes Solix possuem garantia de 2 anos, com suporte técnico e peças originais.",
  },
  {
    icon: "📱",
    title: "App de Segurança",
    desc: "Aplicativo exclusivo para acompanhamento, controle e segurança do seu patinete disponível no site oficial.",
  },
  {
    icon: "💰",
    title: "Melhor Custo-Benefício",
    desc: "Solução econômica de mobilidade urbana que reduz a dependência de combustíveis e da rede elétrica.",
  },
];

const howToUse = [
  { step: "01", title: "Carregue a bateria", desc: "Conecte o carregador na tomada ou posicione o patinete sob o sol para recarga solar." },
  { step: "02", title: "Ligue o patinete", desc: "Pressione o botão de energia no painel para ativar o sistema." },
  { step: "03", title: "Selecione o modo", desc: "Escolha entre Eco, Normal ou Sport conforme sua necessidade." },
  { step: "04", title: "Empurre e acelere", desc: "Dê um leve impulso e use o acelerador do guidão para ganhar velocidade." },
  { step: "05", title: "Aproveite o passeio!", desc: "Em dias ensolarados, o painel solar ajuda a carregar a bateria durante o uso." },
];

const specs = [
  { label: "Comprimento total", value: "1.250 mm" },
  { label: "Altura total", value: "1.180 mm" },
  { label: "Largura do guidão", value: "660 mm" },
  { label: "Largura do deck", value: "260 mm" },
  { label: "Largura do pneu", value: "140 mm" },
  { label: "Diâmetro do pneu", value: "200 mm" },
  { label: "Suspensão", value: "Dianteira e traseira" },
  { label: "Freio", value: "Disco (dianteiro e traseiro)" },
  { label: "Estrutura", value: "Alumínio aeronáutico" },
  { label: "Tipo de pneu", value: "Todo terreno" },
  { label: "Inclinação máx.", value: "até 25° (S3)" },
  { label: "Carga máx. suportada", value: "até 150 kg (S3)" },
];

const faqs = [
  {
    q: "O patinete recarrega apenas com energia solar?",
    a: "Sim! O patinete pode ser carregado exclusivamente pela energia solar captada pelas placas integradas ao deck. Em condições de boa incidência solar, o carregamento completo leva aproximadamente um dia ensolarado. Também é possível carregar via tomada convencional.",
  },
  {
    q: "Qual o público-alvo da Solix?",
    a: "O principal público-alvo são prefeituras e órgãos públicos interessados em soluções de mobilidade urbana sustentável. Também atendemos lojas para revenda, condomínios, hotéis e outras instituições.",
  },
  {
    q: "Os produtos podem ser personalizados?",
    a: "Sim! A Solix oferece possibilidade de personalização dos patinetes conforme as necessidades específicas de cada cliente ou projeto.",
  },
  {
    q: "Qual a garantia dos patinetes Solix?",
    a: "Todos os patinetes Solix possuem garantia de 2 (dois) anos contra defeitos de fabricação, com suporte técnico e peças originais.",
  },
  {
    q: "Como funciona o aplicativo de segurança?",
    a: "O aplicativo Solix pode ser baixado diretamente pelo site oficial da empresa. Ele oferece monitoramento, controle e recursos de segurança para o seu patinete.",
  },
  {
    q: "A Solix atende projetos corporativos e de frota?",
    a: "Sim! A Solix tem experiência em projetos de mobilidade urbana para prefeituras, órgãos públicos, lojas revendedoras e outras instituições, com propostas personalizadas.",
  },
];

/* ─── LOGO SVG ──────────────────────────────────────────── */
function SolixLogo({ size = "md" }: { size?: "sm" | "md" | "lg" }) {
  const h = size === "lg" ? 48 : size === "md" ? 36 : 26;
  return (
    <svg height={h} viewBox="0 0 220 60" fill="none" xmlns="http://www.w3.org/2000/svg" aria-label="Solix">
      {/* S */}
      <text x="0" y="50" fontFamily="Arial Black, sans-serif" fontWeight="900" fontSize="56" fill="white" letterSpacing="-2">S</text>
      {/* O */}
      <text x="38" y="50" fontFamily="Arial Black, sans-serif" fontWeight="900" fontSize="56" fill="white" letterSpacing="-2">O</text>
      {/* star inside O */}
      <polygon points="68,22 70,28 76,28 71,32 73,38 68,34 63,38 65,32 60,28 66,28" fill="#F97316" />
      {/* L */}
      <text x="96" y="50" fontFamily="Arial Black, sans-serif" fontWeight="900" fontSize="56" fill="white" letterSpacing="-2">L</text>
      {/* I */}
      <text x="128" y="50" fontFamily="Arial Black, sans-serif" fontWeight="900" fontSize="56" fill="white" letterSpacing="-2">I</text>
      {/* X with orange gradient */}
      <text x="148" y="50" fontFamily="Arial Black, sans-serif" fontWeight="900" fontSize="56" fill="url(#xgrad)" letterSpacing="-2">X</text>
      <defs>
        <linearGradient id="xgrad" x1="148" y1="0" x2="210" y2="60" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#F97316" />
          <stop offset="100%" stopColor="#FBBF24" />
        </linearGradient>
      </defs>
    </svg>
  );
}

/* ─── SUN ICON ──────────────────────────────────────────── */
function SunIcon({ className = "h-6 w-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <circle cx="12" cy="12" r="4" />
      <path strokeLinecap="round" d="M12 2v2M12 20v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M2 12h2M20 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42" />
    </svg>
  );
}

/* ─── COMPONENTS ────────────────────────────────────────── */
function Badge({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-orange-400/30 bg-orange-400/10 px-4 py-1 text-xs font-bold uppercase tracking-[0.2em] text-orange-300">
      {children}
    </span>
  );
}

function SpecRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-white/8 py-3 last:border-0">
      <span className="text-sm text-slate-400">{label}</span>
      <span className="text-sm font-semibold text-white">{value}</span>
    </div>
  );
}

function FAQItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div
      className={`rounded-2xl border transition-all duration-300 ${open ? "border-orange-400/40 bg-orange-400/5" : "border-white/10 bg-white/4"}`}
    >
      <button
        className="flex w-full items-center justify-between gap-4 p-6 text-left"
        onClick={() => setOpen(!open)}
      >
        <span className="text-base font-semibold text-white">{q}</span>
        <span className={`flex-shrink-0 text-orange-400 transition-transform duration-300 ${open ? "rotate-45" : ""}`}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-5 w-5">
            <path strokeLinecap="round" d="M12 5v14M5 12h14" />
          </svg>
        </span>
      </button>
      {open && <p className="px-6 pb-6 text-sm leading-7 text-slate-300">{a}</p>}
    </div>
  );
}

/* ─── MAIN APP ──────────────────────────────────────────── */
export default function App() {
  const [activeModel, setActiveModel] = useState(1);
  const model = models[activeModel];

  return (
    <div className="min-h-screen bg-[#080808] text-white">
      {/* ── Background glows ── */}
      <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute left-1/4 top-0 h-[40rem] w-[40rem] rounded-full bg-orange-500/8 blur-3xl" />
        <div className="absolute right-0 top-1/3 h-[30rem] w-[30rem] rounded-full bg-amber-400/6 blur-3xl" />
        <div className="absolute bottom-0 left-0 h-[28rem] w-[28rem] rounded-full bg-orange-600/6 blur-3xl" />
      </div>

      {/* ══════════════════════════════════════════
          HEADER
      ══════════════════════════════════════════ */}
      <header className="sticky top-0 z-50 border-b border-white/8 bg-black/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-8">
          <a href="#hero" className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-orange-500 to-amber-400 shadow-[0_0_24px_rgba(249,115,22,0.5)]">
              <SunIcon className="h-5 w-5 text-white" />
            </div>
            <SolixLogo size="sm" />
          </a>

          <nav className="hidden items-center gap-8 text-sm text-slate-300 lg:flex">
            {[["#sobre", "Sobre"], ["#modelos", "Modelos"], ["#tecnologia", "Tecnologia"], ["#uso", "Como Usar"], ["#faq", "FAQ"]].map(([href, label]) => (
              <a key={href} href={href} className="transition hover:text-orange-400">{label}</a>
            ))}
          </nav>

          <a
            href="#contato"
            className="rounded-full bg-gradient-to-r from-orange-500 to-amber-400 px-5 py-2.5 text-sm font-bold text-black shadow-[0_0_20px_rgba(249,115,22,0.4)] transition hover:shadow-[0_0_30px_rgba(249,115,22,0.6)]"
          >
            Solicitar Proposta
          </a>
        </div>
      </header>

      <main>
        {/* ══════════════════════════════════════════
            HERO
        ══════════════════════════════════════════ */}
        <section id="hero" className="relative mx-auto max-w-7xl px-6 pb-16 pt-20 lg:px-8 lg:pt-28">
          <div className="grid items-center gap-14 lg:grid-cols-[1.1fr_0.9fr]">
            <div>
              <Badge><SunIcon className="h-3.5 w-3.5" /> Energia Solar · 100% Elétrico · Sustentável</Badge>

              <h1 className="mt-6 text-5xl font-black leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl">
                A energia do sol
                <br />
                <span className="bg-gradient-to-r from-orange-400 via-amber-300 to-yellow-400 bg-clip-text text-transparent">
                  te leva mais longe.
                </span>
              </h1>

              <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-300">
                A <strong className="text-white">Solix</strong> é especializada em patinetes elétricos movidos a energia solar. Mobilidade prática, econômica e sustentável — com possibilidade de personalização para cada cliente.
              </p>

              <div className="mt-10 flex flex-col gap-4 sm:flex-row">
                <a
                  href="#modelos"
                  className="inline-flex items-center justify-center rounded-full bg-gradient-to-r from-orange-500 to-amber-400 px-8 py-4 text-sm font-bold text-black shadow-[0_0_30px_rgba(249,115,22,0.4)] transition hover:shadow-[0_0_40px_rgba(249,115,22,0.6)]"
                >
                  Ver Modelos
                </a>
                <a
                  href="#contato"
                  className="inline-flex items-center justify-center rounded-full border border-white/15 bg-white/5 px-8 py-4 text-sm font-bold text-white transition hover:border-orange-400/40 hover:bg-white/10"
                >
                  Solicitar Proposta
                </a>
              </div>

              {/* Pills */}
              <div className="mt-12 flex flex-wrap gap-3">
                {[
                  ["☀️", "Recarga Solar"],
                  ["⚡", "Zero Emissões"],
                  ["🔒", "App de Segurança"],
                  ["🛡️", "2 Anos de Garantia"],
                  ["🔧", "Personalizável"],
                ].map(([icon, label]) => (
                  <span key={label} className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-slate-200">
                    <span>{icon}</span>{label}
                  </span>
                ))}
              </div>
            </div>

            <div className="relative">
              {/* Floating badge */}
              <div className="absolute -right-4 top-6 z-10 hidden rounded-2xl border border-orange-400/30 bg-black/80 px-4 py-3 shadow-2xl backdrop-blur md:block">
                <p className="text-xs uppercase tracking-widest text-orange-300">Recarga Solar</p>
                <p className="mt-1 text-lg font-bold text-white">Sem depender da tomada</p>
              </div>

              <div className="relative overflow-hidden rounded-[2rem] border border-white/10 bg-gradient-to-b from-orange-500/10 to-transparent p-3 shadow-[0_40px_120px_rgba(0,0,0,0.8)]">
                <img
                  src="/images/solix-hero.jpg"
                  alt="Patinete elétrico Solix movido a energia solar"
                  className="h-[38rem] w-full rounded-[1.5rem] object-cover object-center"
                />
                {/* Overlay badge */}
                <div className="absolute inset-x-5 bottom-5 rounded-2xl border border-white/10 bg-black/75 p-5 backdrop-blur-xl">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p className="text-xs uppercase tracking-widest text-orange-300">Flagship</p>
                      <p className="mt-1 text-xl font-bold">Solix S3 · Alta Performance</p>
                    </div>
                    <div className="flex items-center gap-2 rounded-full bg-orange-500/20 px-3 py-1.5 text-sm text-orange-200">
                      <SunIcon className="h-4 w-4" /> 80 km de autonomia
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ══════════════════════════════════════════
            SOBRE
        ══════════════════════════════════════════ */}
        <section id="sobre" className="mx-auto max-w-7xl px-6 py-24 lg:px-8">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <div>
              <Badge>Sobre a Solix</Badge>
              <h2 className="mt-5 text-4xl font-black tracking-tight sm:text-5xl">
                Mais mobilidade.<br />
                <span className="text-orange-400">Um futuro mais limpo.</span>
              </h2>
              <p className="mt-5 text-lg leading-8 text-slate-300">
                A Solix é uma empresa especializada na <strong className="text-white">venda e produção de patinetes elétricos movidos a energia solar</strong>. Nossa proposta é oferecer uma alternativa de mobilidade prática, econômica e sustentável.
              </p>
              <p className="mt-4 text-base leading-7 text-slate-400">
                Nosso principal público-alvo são <strong className="text-white">prefeituras e órgãos públicos</strong> interessados em soluções de mobilidade urbana — além de lojas para revenda, condomínios, hotéis e outras instituições.
              </p>
              <div className="mt-8 grid gap-4 sm:grid-cols-2">
                {[
                  ["🏛️", "Prefeituras", "Principal público-alvo"],
                  ["🏪", "Lojas Parceiras", "Rede de revendas"],
                  ["🏢", "Instituições", "Projetos corporativos"],
                  ["🌱", "Sustentabilidade", "Zero emissões"],
                ].map(([icon, title, sub]) => (
                  <div key={title} className="rounded-2xl border border-white/10 bg-white/5 p-5">
                    <span className="text-2xl">{icon}</span>
                    <p className="mt-2 font-bold text-white">{title}</p>
                    <p className="text-sm text-slate-400">{sub}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Stats */}
            <div className="rounded-[2rem] border border-orange-400/20 bg-gradient-to-br from-orange-500/10 via-amber-400/5 to-transparent p-8">
              <p className="text-sm font-bold uppercase tracking-widest text-orange-300">Nossos números</p>
              <div className="mt-6 grid grid-cols-2 gap-6">
                {[
                  ["80 km", "Autonomia máxima (S3)"],
                  ["40 km/h", "Velocidade máx. (S3)"],
                  ["2 anos", "Garantia do produto"],
                  ["3 modelos", "Linha completa"],
                  ["350–750W", "Motores disponíveis"],
                  ["100%", "Energia solar"],
                ].map(([val, label]) => (
                  <div key={label} className="rounded-2xl border border-white/8 bg-black/40 p-5">
                    <p className="text-2xl font-black text-orange-400">{val}</p>
                    <p className="mt-1 text-sm text-slate-400">{label}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* ══════════════════════════════════════════
            BENEFÍCIOS
        ══════════════════════════════════════════ */}
        <section className="mx-auto max-w-7xl px-6 py-8 lg:px-8">
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {benefits.map((b) => (
              <div key={b.title} className="rounded-2xl border border-white/10 bg-white/4 p-6 transition hover:border-orange-400/30 hover:bg-orange-400/5">
                <span className="text-3xl">{b.icon}</span>
                <h3 className="mt-4 text-lg font-bold text-white">{b.title}</h3>
                <p className="mt-2 text-sm leading-7 text-slate-400">{b.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* ══════════════════════════════════════════
            MODELOS
        ══════════════════════════════════════════ */}
        <section id="modelos" className="mx-auto max-w-7xl px-6 py-24 lg:px-8">
          <div className="mb-12">
            <Badge>Nossos Modelos</Badge>
            <h2 className="mt-5 text-4xl font-black tracking-tight sm:text-5xl">
              Escolha o que mais<br />
              <span className="text-orange-400">combina com você.</span>
            </h2>
            <p className="mt-4 max-w-2xl text-lg text-slate-400">
              Três modelos com diferentes níveis de autonomia, potência e performance — todos movidos a energia solar.
            </p>
          </div>

          {/* Tabs */}
          <div className="mb-8 flex gap-3">
            {models.map((m, i) => (
              <button
                key={m.id}
                onClick={() => setActiveModel(i)}
                className={`rounded-full px-6 py-2.5 text-sm font-bold transition ${
                  activeModel === i
                    ? "bg-gradient-to-r from-orange-500 to-amber-400 text-black shadow-[0_0_20px_rgba(249,115,22,0.4)]"
                    : "border border-white/15 bg-white/5 text-slate-300 hover:border-orange-400/30"
                }`}
              >
                {m.id}
              </button>
            ))}
          </div>

          {/* Active Model Detail */}
          <div className={`rounded-[2rem] border bg-gradient-to-br ${model.color} ${model.border} p-0 overflow-hidden`}>
            <div className="grid lg:grid-cols-[1fr_1fr]">
              {/* Image */}
              <div className="relative h-80 overflow-hidden lg:h-auto">
                <img
                  src={model.image}
                  alt={model.name}
                  className="h-full w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-transparent to-black/60 lg:bg-gradient-to-t lg:from-black/40 lg:to-transparent" />
                <div className="absolute left-6 top-6 rounded-full bg-black/70 px-4 py-2 text-sm font-bold text-orange-300 backdrop-blur">
                  {model.tag}
                </div>
              </div>

              {/* Info */}
              <div className="p-8 lg:p-10">
                <p className="text-sm font-bold uppercase tracking-widest text-orange-400">Solix</p>
                <h3 className="mt-1 text-4xl font-black text-white">{model.name}</h3>
                <p className="mt-3 text-base text-slate-300">{model.highlight}</p>

                <div className="mt-8 grid grid-cols-2 gap-4">
                  {[
                    ["🛣️", "Autonomia", model.autonomy],
                    ["⚡", "Velocidade máx.", model.speed],
                    ["⚖️", "Peso", model.weight],
                    ["☀️", "Carga solar", model.charge],
                    ["🔋", "Motor", model.motor],
                    ["🔌", "Bateria", model.battery],
                  ].map(([icon, label, val]) => (
                    <div key={label} className="rounded-xl border border-white/10 bg-black/30 p-4">
                      <p className="flex items-center gap-1.5 text-xs uppercase tracking-wider text-slate-400">
                        <span>{icon}</span>{label}
                      </p>
                      <p className="mt-1.5 text-base font-bold text-white">{val}</p>
                    </div>
                  ))}
                </div>

                <div className="mt-8 flex gap-3">
                  <a
                    href="#contato"
                    className="flex-1 rounded-full bg-gradient-to-r from-orange-500 to-amber-400 py-3.5 text-center text-sm font-bold text-black shadow-[0_0_20px_rgba(249,115,22,0.35)] transition hover:shadow-[0_0_30px_rgba(249,115,22,0.55)]"
                  >
                    Solicitar Proposta
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* All Models Grid (mini cards) */}
          <div className="mt-8 grid gap-5 sm:grid-cols-3">
            {models.map((m, i) => (
              <button
                key={m.id}
                onClick={() => setActiveModel(i)}
                className={`rounded-2xl border p-5 text-left transition ${
                  activeModel === i ? "border-orange-400/50 bg-orange-400/10" : "border-white/10 bg-white/4 hover:border-orange-400/20"
                }`}
              >
                <p className="text-xs font-bold uppercase tracking-widest text-orange-400">{m.id}</p>
                <p className="mt-1 text-lg font-black text-white">{m.name}</p>
                <p className="mt-1 text-sm text-slate-400">{m.tag}</p>
                <div className="mt-4 flex gap-3">
                  <span className="rounded-full bg-white/8 px-3 py-1 text-xs font-semibold text-slate-200">{m.autonomy}</span>
                  <span className="rounded-full bg-white/8 px-3 py-1 text-xs font-semibold text-slate-200">{m.motor}</span>
                </div>
              </button>
            ))}
          </div>
        </section>

        {/* ══════════════════════════════════════════
            TECNOLOGIA SOLAR
        ══════════════════════════════════════════ */}
        <section id="tecnologia" className="mx-auto max-w-7xl px-6 py-24 lg:px-8">
          <div className="overflow-hidden rounded-[2.5rem] border border-orange-400/20 bg-gradient-to-br from-orange-500/10 via-amber-400/5 to-black p-8 lg:p-14">
            <div className="grid items-center gap-12 lg:grid-cols-2">
              <div>
                <Badge><SunIcon className="h-3.5 w-3.5" /> Tecnologia Solar</Badge>
                <h2 className="mt-5 text-4xl font-black tracking-tight sm:text-5xl">
                  Carregado pelo sol,<br />
                  <span className="text-orange-400">livre da tomada.</span>
                </h2>
                <p className="mt-5 text-base leading-8 text-slate-300">
                  O patinete Solix utiliza <strong className="text-white">placas e painéis solares</strong> integrados ao deck para captar a energia do sol e transformá-la em energia para recarregar a bateria.
                </p>
                <p className="mt-4 text-base leading-8 text-slate-300">
                  Em condições de boa incidência solar, o carregamento completo pode levar <strong className="text-white">aproximadamente um dia ensolarado inteiro</strong>. O equipamento pode ser carregado em qualquer local com disponibilidade de luz solar, proporcionando maior autonomia e praticidade.
                </p>

                <div className="mt-8 space-y-4">
                  {[
                    ["☀️", "Placas/painéis solares para captação de energia"],
                    ["🔋", "Bateria recarregável de íon de lítio para armazenamento"],
                    ["⚡", "Sistema de conversão e gerenciamento da energia solar"],
                    ["🔌", "Recarga independente da rede elétrica"],
                    ["🛣️", "Carregamento possível durante o uso em dias ensolarados"],
                  ].map(([icon, text]) => (
                    <div key={text} className="flex items-start gap-4 rounded-xl border border-white/8 bg-black/30 p-4">
                      <span className="mt-0.5 text-xl">{icon}</span>
                      <p className="text-sm leading-6 text-slate-200">{text}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Solar diagram visual */}
              <div className="relative">
                <div className="rounded-[2rem] border border-orange-400/20 bg-black/50 p-8 text-center">
                  {/* Sun */}
                  <div className="mx-auto flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-br from-orange-400 to-amber-300 shadow-[0_0_60px_rgba(249,115,22,0.6)]">
                    <SunIcon className="h-12 w-12 text-white" />
                  </div>
                  <div className="mt-4 text-sm font-semibold uppercase tracking-widest text-orange-300">Energia Solar</div>

                  {/* Arrow down */}
                  <div className="my-4 flex justify-center">
                    <div className="flex flex-col items-center gap-1">
                      {[...Array(4)].map((_, i) => (
                        <div key={i} className="h-2 w-2 rounded-full bg-orange-400 opacity-75" />
                      ))}
                      <svg className="h-5 w-5 text-orange-400" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 16l-6-6h12z" />
                      </svg>
                    </div>
                  </div>

                  {/* Panel */}
                  <div className="rounded-xl border border-orange-400/30 bg-orange-400/10 p-4">
                    <p className="text-xs font-bold uppercase tracking-widest text-orange-300">Painel Solar</p>
                    <p className="mt-1 text-sm text-slate-300">Captação e conversão de energia</p>
                  </div>

                  {/* Arrow */}
                  <div className="my-4 flex justify-center">
                    <svg className="h-5 w-5 text-amber-400" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M12 16l-6-6h12z" />
                    </svg>
                  </div>

                  {/* Battery */}
                  <div className="rounded-xl border border-amber-400/30 bg-amber-400/10 p-4">
                    <p className="text-xs font-bold uppercase tracking-widest text-amber-300">Bateria de Íon de Lítio</p>
                    <p className="mt-1 text-sm text-slate-300">Armazenamento e gerenciamento</p>
                  </div>

                  {/* Arrow */}
                  <div className="my-4 flex justify-center">
                    <svg className="h-5 w-5 text-yellow-400" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M12 16l-6-6h12z" />
                    </svg>
                  </div>

                  {/* Motor */}
                  <div className="rounded-xl border border-yellow-400/30 bg-yellow-400/10 p-4">
                    <p className="text-xs font-bold uppercase tracking-widest text-yellow-300">Motor Elétrico</p>
                    <p className="mt-1 text-sm text-slate-300">Propulsão silenciosa e eficiente</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ══════════════════════════════════════════
            ESPECIFICAÇÕES TÉCNICAS
        ══════════════════════════════════════════ */}
        <section className="mx-auto max-w-7xl px-6 py-8 lg:px-8">
          <div className="grid gap-8 lg:grid-cols-2">
            <div>
              <Badge>Especificações Técnicas</Badge>
              <h2 className="mt-5 text-3xl font-black tracking-tight sm:text-4xl">
                Detalhes que fazem<br />
                <span className="text-orange-400">a diferença.</span>
              </h2>
              <p className="mt-4 text-base leading-7 text-slate-400">
                Engenharia pensada para oferecer resistência, conforto e performance nas ruas da cidade.
              </p>

              <div className="mt-8 rounded-2xl border border-white/10 bg-white/4 p-6">
                {specs.map((s) => <SpecRow key={s.label} label={s.label} value={s.value} />)}
              </div>
            </div>

            <div className="space-y-5">
              {[
                { icon: "⚙️", title: "Motor Elétrico", desc: "350W (S1), 500W (S2) e 750W (S3) — potência adaptada a cada necessidade." },
                { icon: "🔋", title: "Bateria de Íon de Lítio", desc: "Alta densidade energética com sistema de gerenciamento inteligente para mais ciclos de carga." },
                { icon: "🛞", title: "Pneus Todo Terreno", desc: "Pneus sólidos e resistentes, 8,5\" (S1) e 10\" (S2/S3), para qualquer tipo de piso urbano." },
                { icon: "🛡️", title: "Freio a Disco + E-ABS", desc: "Sistema de frenagem de alta eficiência dianteiro e traseiro com controle eletrônico." },
                { icon: "🏗️", title: "Estrutura Aeronáutica", desc: "Alumínio aeronáutico — leve, resistente e com acabamento premium." },
              ].map((item) => (
                <div key={item.title} className="flex gap-4 rounded-2xl border border-white/10 bg-white/4 p-5 transition hover:border-orange-400/20">
                  <span className="mt-0.5 flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-xl bg-orange-400/10 text-xl">{item.icon}</span>
                  <div>
                    <p className="font-bold text-white">{item.title}</p>
                    <p className="mt-1 text-sm leading-6 text-slate-400">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ══════════════════════════════════════════
            COMO USAR
        ══════════════════════════════════════════ */}
        <section id="uso" className="mx-auto max-w-7xl px-6 py-24 lg:px-8">
          <div className="text-center">
            <Badge>Como Usar</Badge>
            <h2 className="mt-5 text-4xl font-black tracking-tight sm:text-5xl">
              Simples, rápido e seguro.
            </h2>
            <p className="mx-auto mt-4 max-w-2xl text-lg text-slate-400">
              Comece a usar seu patinete Solix em poucos passos.
            </p>
          </div>

          <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-5">
            {howToUse.map((item) => (
              <div key={item.step} className="relative rounded-2xl border border-white/10 bg-white/4 p-6 transition hover:border-orange-400/30">
                <p className="text-4xl font-black text-orange-400/30">{item.step}</p>
                <h3 className="mt-3 font-bold text-white">{item.title}</h3>
                <p className="mt-2 text-sm leading-6 text-slate-400">{item.desc}</p>
              </div>
            ))}
          </div>

          {/* Tip */}
          <div className="mt-8 rounded-2xl border border-orange-400/30 bg-orange-400/8 p-6">
            <div className="flex items-start gap-4">
              <span className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl bg-orange-400/20 text-xl">💡</span>
              <div>
                <p className="font-bold text-orange-300">Dica Solix</p>
                <p className="mt-1 text-sm leading-6 text-slate-300">
                  Em dias ensolarados, posicione o patinete de forma que o painel solar receba luz direta para maior eficiência de recarga. Você também pode carregar a bateria durante o uso nos trajetos.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ══════════════════════════════════════════
            MODOS DE CONDUÇÃO
        ══════════════════════════════════════════ */}
        <section className="mx-auto max-w-7xl px-6 py-8 lg:px-8">
          <div className="grid gap-5 sm:grid-cols-3">
            {[
              {
                mode: "ECO",
                desc: "Maior autonomia (até 25 km/h). Ideal para trajetos longos e economia máxima de bateria.",
                color: "from-green-500/20 to-green-500/5",
                border: "border-green-400/30",
                badge: "text-green-300",
              },
              {
                mode: "NORMAL",
                desc: "Equilíbrio entre velocidade e autonomia (até 30 km/h). Uso cotidiano com conforto.",
                color: "from-blue-500/20 to-blue-500/5",
                border: "border-blue-400/30",
                badge: "text-blue-300",
              },
              {
                mode: "SPORT",
                desc: "Máxima potência e velocidade (até 40 km/h). Para quem quer mais adrenalina.",
                color: "from-orange-500/20 to-orange-500/5",
                border: "border-orange-400/30",
                badge: "text-orange-300",
              },
            ].map((m) => (
              <div key={m.mode} className={`rounded-2xl border bg-gradient-to-br ${m.color} ${m.border} p-6`}>
                <p className={`text-xs font-black uppercase tracking-widest ${m.badge}`}>Modo</p>
                <p className="mt-1 text-3xl font-black text-white">{m.mode}</p>
                <p className="mt-3 text-sm leading-6 text-slate-300">{m.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* ══════════════════════════════════════════
            APP DE SEGURANÇA
        ══════════════════════════════════════════ */}
        <section className="mx-auto max-w-7xl px-6 py-24 lg:px-8">
          <div className="overflow-hidden rounded-[2.5rem] border border-white/10 bg-gradient-to-br from-slate-900 to-black p-8 lg:p-14">
            <div className="grid items-center gap-10 lg:grid-cols-2">
              <div>
                <Badge>App de Segurança</Badge>
                <h2 className="mt-5 text-4xl font-black tracking-tight">
                  Seu patinete na palma<br />
                  <span className="text-orange-400">da mão.</span>
                </h2>
                <p className="mt-5 text-base leading-8 text-slate-300">
                  A Solix disponibiliza, por meio do site oficial, acesso ao <strong className="text-white">aplicativo de segurança</strong> desenvolvido para auxiliar na utilização e no acompanhamento do produto.
                </p>
                <div className="mt-8 space-y-4">
                  {[
                    ["📍", "Rastreamento em tempo real"],
                    ["🔒", "Travamento e destravamento remoto"],
                    ["📊", "Monitoramento de bateria e autonomia"],
                    ["🔔", "Alertas e notificações de segurança"],
                    ["🛠️", "Agendamento de revisões e manutenções"],
                    ["📞", "Acesso ao suporte técnico Solix"],
                  ].map(([icon, feat]) => (
                    <div key={feat} className="flex items-center gap-3 rounded-xl border border-white/8 bg-white/4 px-5 py-3.5">
                      <span className="text-xl">{icon}</span>
                      <span className="text-sm font-semibold text-slate-200">{feat}</span>
                    </div>
                  ))}
                </div>
                <p className="mt-6 text-sm text-slate-400">
                  Disponível para download diretamente no site oficial da Solix.
                </p>
              </div>

              {/* Phone mockup */}
              <div className="flex justify-center">
                <div className="relative w-64">
                  <div className="rounded-[2.5rem] border-[6px] border-white/20 bg-gradient-to-b from-slate-800 to-slate-900 p-4 shadow-[0_40px_100px_rgba(0,0,0,0.8)]">
                    {/* Status bar */}
                    <div className="mb-3 flex items-center justify-between px-2">
                      <span className="text-xs text-white">9:41</span>
                      <div className="flex gap-1">
                        <div className="h-2.5 w-2.5 rounded-full bg-orange-400" />
                        <div className="h-2.5 w-2.5 rounded-full bg-green-400" />
                        <div className="h-2.5 w-2.5 rounded-full bg-white/60" />
                      </div>
                    </div>
                    {/* App Header */}
                    <div className="rounded-2xl bg-gradient-to-r from-orange-500 to-amber-400 p-4 text-center">
                      <p className="text-xs font-bold uppercase tracking-widest text-black">SOLIX APP</p>
                      <p className="mt-1 text-2xl font-black text-black">Segurança</p>
                    </div>
                    {/* Battery */}
                    <div className="mt-4 rounded-xl bg-white/8 p-4">
                      <p className="text-xs text-slate-400">Bateria</p>
                      <div className="mt-2 h-3 rounded-full bg-white/10">
                        <div className="h-3 w-3/4 rounded-full bg-gradient-to-r from-orange-500 to-amber-300" />
                      </div>
                      <p className="mt-1 text-right text-sm font-bold text-orange-300">75%</p>
                    </div>
                    {/* Status */}
                    <div className="mt-3 rounded-xl bg-green-500/10 p-3 text-center">
                      <p className="text-xs font-bold text-green-400">● Conectado · Travado</p>
                    </div>
                    {/* Autonomy */}
                    <div className="mt-3 grid grid-cols-2 gap-2">
                      <div className="rounded-xl bg-white/8 p-3 text-center">
                        <p className="text-xs text-slate-400">Autonomia</p>
                        <p className="mt-1 text-sm font-bold text-white">58 km</p>
                      </div>
                      <div className="rounded-xl bg-white/8 p-3 text-center">
                        <p className="text-xs text-slate-400">Solar</p>
                        <p className="mt-1 text-sm font-bold text-orange-300">Ativo ☀️</p>
                      </div>
                    </div>
                    {/* CTA button */}
                    <button className="mt-4 w-full rounded-2xl bg-gradient-to-r from-orange-500 to-amber-400 py-3 text-sm font-bold text-black">
                      🔓 Destravar
                    </button>
                  </div>
                  {/* Notch */}
                  <div className="absolute left-1/2 top-2 h-4 w-20 -translate-x-1/2 rounded-full bg-black/80" />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ══════════════════════════════════════════
            PÚBLICO-ALVO
        ══════════════════════════════════════════ */}
        <section className="mx-auto max-w-7xl px-6 py-8 lg:px-8">
          <div className="text-center">
            <Badge>Quem Atendemos</Badge>
            <h2 className="mt-5 text-4xl font-black tracking-tight">
              Soluções para quem<br />
              <span className="text-orange-400">move cidades.</span>
            </h2>
          </div>

          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: "🏛️", title: "Prefeituras", desc: "Principal público-alvo. Projetos de mobilidade urbana sustentável para cidades mais inteligentes." },
              { icon: "🏢", title: "Órgãos Públicos", desc: "Instituições governamentais que buscam alternativas práticas e econômicas de transporte." },
              { icon: "🏪", title: "Lojas Parceiras", desc: "Rede de revendas autorizadas com suporte técnico e portfólio completo Solix." },
              { icon: "🏗️", title: "Outras Instituições", desc: "Condomínios, hotéis, empresas e qualquer projeto que valorize mobilidade sustentável." },
            ].map((item) => (
              <div key={item.title} className="rounded-2xl border border-white/10 bg-white/4 p-7 transition hover:border-orange-400/30 hover:bg-orange-400/5">
                <span className="text-4xl">{item.icon}</span>
                <h3 className="mt-4 text-xl font-black text-white">{item.title}</h3>
                <p className="mt-2 text-sm leading-7 text-slate-400">{item.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* ══════════════════════════════════════════
            FAQ
        ══════════════════════════════════════════ */}
        <section id="faq" className="mx-auto max-w-4xl px-6 py-24 lg:px-8">
          <div className="text-center">
            <Badge>Perguntas Frequentes</Badge>
            <h2 className="mt-5 text-4xl font-black tracking-tight">
              Tudo sobre a <span className="text-orange-400">Solix</span>
            </h2>
          </div>

          <div className="mt-12 space-y-3">
            {faqs.map((item) => <FAQItem key={item.q} q={item.q} a={item.a} />)}
          </div>
        </section>

        {/* ══════════════════════════════════════════
            CONTATO / CTA
        ══════════════════════════════════════════ */}
        <section id="contato" className="mx-auto max-w-7xl px-6 pb-20 lg:px-8">
          <div className="overflow-hidden rounded-[2.5rem] border border-orange-400/25 bg-gradient-to-br from-orange-500/15 via-amber-400/8 to-black p-8 shadow-[0_40px_120px_rgba(249,115,22,0.15)] lg:p-14">
            <div className="grid items-center gap-10 lg:grid-cols-[1fr_auto]">
              <div>
                <Badge><SunIcon className="h-3.5 w-3.5" /> Fale com a Solix</Badge>
                <h2 className="mt-5 text-4xl font-black tracking-tight sm:text-5xl">
                  Pronto para levar a<br />
                  <span className="text-orange-400">energia solar para sua cidade?</span>
                </h2>
                <p className="mt-5 max-w-2xl text-lg text-slate-300">
                  Entre em contato com a nossa equipe para solicitar uma proposta, agendar uma demonstração ou saber mais sobre projetos de mobilidade urbana sustentável com a Solix.
                </p>

                <div className="mt-8 grid gap-4 sm:grid-cols-3">
                  {[
                    ["📞", "Telefone", "(11) 98765-4321"],
                    ["📧", "E-mail", "contato@solix.com.br"],
                    ["🌐", "Site", "www.solix.com.br"],
                  ].map(([icon, label, val]) => (
                    <div key={label} className="rounded-2xl border border-white/10 bg-black/40 p-5">
                      <span className="text-2xl">{icon}</span>
                      <p className="mt-2 text-xs uppercase tracking-widest text-slate-400">{label}</p>
                      <p className="mt-1 font-bold text-white">{val}</p>
                    </div>
                  ))}
                </div>

                {/* Social */}
                <div className="mt-6 flex flex-wrap gap-3">
                  {["@solixpatinetes", "solix.com.br"].map((s) => (
                    <span key={s} className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-slate-300">
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex flex-col gap-4">
                <a
                  href="mailto:contato@solix.com.br"
                  className="inline-flex items-center justify-center rounded-full bg-gradient-to-r from-orange-500 to-amber-400 px-8 py-4 text-sm font-bold text-black shadow-[0_0_30px_rgba(249,115,22,0.4)] transition hover:shadow-[0_0_50px_rgba(249,115,22,0.6)]"
                >
                  📧 Enviar E-mail
                </a>
                <a
                  href="tel:+5511987654321"
                  className="inline-flex items-center justify-center rounded-full border border-white/20 bg-white/8 px-8 py-4 text-sm font-bold text-white transition hover:border-orange-400/40 hover:bg-white/12"
                >
                  📞 Ligar Agora
                </a>
                <a
                  href="#modelos"
                  className="inline-flex items-center justify-center rounded-full border border-orange-400/30 bg-orange-400/10 px-8 py-4 text-sm font-bold text-orange-300 transition hover:bg-orange-400/15"
                >
                  🛴 Ver Modelos
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* ══════════════════════════════════════════
          FOOTER
      ══════════════════════════════════════════ */}
      <footer className="border-t border-white/8 bg-black px-6 py-10 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
            <div>
              <SolixLogo size="sm" />
              <p className="mt-4 text-sm leading-6 text-slate-400">
                Patinetes elétricos movidos a energia solar. Mais mobilidade. Um futuro mais limpo.
              </p>
              <p className="mt-4 flex items-center gap-2 text-xs text-orange-400">
                <SunIcon className="h-4 w-4" /> Tecnologia Sustentável
              </p>
            </div>

            <div>
              <p className="mb-4 text-sm font-bold uppercase tracking-widest text-slate-300">Produtos</p>
              <div className="space-y-2 text-sm text-slate-400">
                <p>Solix S1 — Equilíbrio Perfeito</p>
                <p>Solix S2 — Mais Potência</p>
                <p>Solix S3 — Alta Performance</p>
                <p>Acessórios e Peças</p>
              </div>
            </div>

            <div>
              <p className="mb-4 text-sm font-bold uppercase tracking-widest text-slate-300">Empresa</p>
              <div className="space-y-2 text-sm text-slate-400">
                <a href="#sobre" className="block transition hover:text-orange-400">Sobre a Solix</a>
                <a href="#tecnologia" className="block transition hover:text-orange-400">Tecnologia Solar</a>
                <a href="#modelos" className="block transition hover:text-orange-400">Modelos</a>
                <a href="#contato" className="block transition hover:text-orange-400">Contato</a>
              </div>
            </div>

            <div>
              <p className="mb-4 text-sm font-bold uppercase tracking-widest text-slate-300">Contato</p>
              <div className="space-y-2 text-sm text-slate-400">
                <p>📞 (11) 98765-4321</p>
                <p>📧 contato@solix.com.br</p>
                <p>🌐 www.solix.com.br</p>
                <p>📱 @solixpatinetes</p>
              </div>
            </div>
          </div>

          <div className="mt-10 flex flex-col items-center justify-between gap-4 border-t border-white/8 pt-8 text-xs text-slate-500 sm:flex-row">
            <p>© 2026 Solix Patinetes Elétricos. Todos os direitos reservados.</p>
            <p className="flex items-center gap-1.5">
              <SunIcon className="h-3.5 w-3.5 text-orange-400" />
              Tecnologia Sustentável · Mobilidade Inteligente · Energia Renovável
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
